package com.dbms.project.model;

import lombok.Data;

@Data
public class Willingness {
    private Integer companyID;
    private String roleName;
    private Integer rollNo;
    private String resumeName;
}
